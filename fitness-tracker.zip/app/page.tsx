import Dashboard from "@/components/dashboard/dashboard"

export default function Home() {
  return (
    <main>
      <Dashboard />
    </main>
  )
}
